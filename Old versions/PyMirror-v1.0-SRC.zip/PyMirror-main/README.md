# PyMirror ( v2.0 )
PyMirror is a open source Mirroring Service. It helps in uploading your files to multiple file hosting providers
- GUI photo: https://imgur.com/a/5tZ9UY8

## Future updates
- Settings tap
- +30 More websites
- Fix bugs & lag
- New additions
